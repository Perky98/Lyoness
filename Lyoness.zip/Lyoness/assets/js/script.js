function loadContent(file, elementId) {
    fetch(file)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(data => {
            let elm = document.getElementById(elementId);
            if(elm !== null) {
                elm.innerHTML = data;
            }
        })
        .catch(error => {
            console.error('Error fetching file:', error);
        });
}

loadContent('header.html', 'header');
loadContent('main.html', 'main-page');
loadContent('details.html', 'details-page');
loadContent('footer.html', 'footer');